package com.example.sensormeasurementapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.CheckBox;
import android.widget.EditText;

import java.io.ObjectStreamException;
import java.util.ArrayList;

public class ConfigurationActivity extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    ArrayList<Boolean> objectTypes;
    int minBound, maxBound, minRotationDegree, maxRotationDegree;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        editor = sharedPreferences.edit();
        setContentView(R.layout.activity_configuration);

        // Fetch relevant data from Shared Preferences
        String objectTypesString = sharedPreferences.getString(getString(R.string.shapes_cb_file_key), "01");
        minBound = sharedPreferences.getInt(getString(R.string.size_min_bound_file_key), 10);
        maxBound = sharedPreferences.getInt(getString(R.string.size_max_bound_file_key), 500);
        minRotationDegree = sharedPreferences.getInt(getString(R.string.rotation_min_bound_file_key), 0);
        maxRotationDegree = sharedPreferences.getInt(getString(R.string.rotation_max_bound_file_key), 0);

        EditText maxSizeET = findViewById(R.id.maxSizeInputText);
        EditText minSizeET = findViewById(R.id.minSizeInputText);
        EditText maxRotationET = findViewById(R.id.maxRotationInputText);
        EditText minRotationET = findViewById(R.id.minRotationInputText);

        ArrayList<EditText> configETs = new ArrayList<>();
        configETs.add(maxSizeET);
        configETs.add(minSizeET);
        configETs.add(maxRotationET);
        configETs.add(minRotationET);

        int[] configETsIDs = new int[]{R.id.maxSizeInputText, R.id.minSizeInputText, R.id.maxRotationInputText, R.id.minRotationInputText};

        maxSizeET.setText(String.valueOf(maxBound));
        minSizeET.setText(String.valueOf(minBound));
        maxRotationET.setText(String.valueOf(maxRotationDegree));
        minRotationET.setText(String.valueOf(minRotationDegree));

        for (int i = 0; i < configETs.size(); i++) {
            EditText ET = configETs.get(i);
            int finalI = i;
            ET.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    System.out.println("BEFORE TEXT CHANGED");
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    System.out.println("ON TEXT CHANGED");
                }

                @Override
                public void afterTextChanged(Editable s) {
                    int valueET = 0;
                    if (!s.toString().isEmpty()) {
                        valueET = Integer.parseInt(s.toString());
                    }

                    switch (finalI) {
                        case 0:
                            maxBound = valueET;
                            break;
                        case 1:
                            minBound = valueET;
                            break;
                        case 2:
                            maxRotationDegree = valueET;
                            break;
                        case 3:
                            minRotationDegree = valueET;
                            break;
                    }
                    System.out.println("AFTER TEXT CHANGED");
                    System.out.println("finalI: " + finalI);
                }
            });
        }

        System.out.println("objectTypesString: " + objectTypesString);
        objectTypes = MainActivity.stringToBoolArray(objectTypesString);


        int[] objectTypeIds = new int[]{R.id.circleCB, R.id.squaresCB, R.id.trianglesCB};

        for (int i = 0; i < objectTypes.size(); i++) {
            CheckBox cb = findViewById(objectTypeIds[i]);
            if (objectTypes.get(i)) {
                cb.setChecked(true);
            } else {
                cb.setChecked(false);
            }
        }

    }

    private String getEnabledShapes() {
        int[] objectCBids = new int[]{R.id.circleCB, R.id.squaresCB, R.id.trianglesCB};
        String result = "";

        for (int i = 0; i < objectCBids.length; i++) {
            CheckBox cb = findViewById(objectCBids[i]);
            if (cb.isChecked()) {
                result += "1";
            } else {
                result += "0";
            }
        }

        return result;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //editor.commit();

        //Intent intent = new Intent(this, MainActivity.class);
        //startActivity(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();

        // Commit configuration / preferences data to Shared Preferences
        editor.putString(getString(R.string.shapes_cb_file_key), getEnabledShapes());
        editor.putInt(getString(R.string.size_max_bound_file_key), maxBound);
        editor.putInt(getString(R.string.size_min_bound_file_key), minBound);
        editor.putInt(getString(R.string.rotation_max_bound_file_key), maxRotationDegree);
        editor.putInt(getString(R.string.rotation_min_bound_file_key), minRotationDegree);

        editor.commit();
    }

    private class SharedPreferencesAsyncTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            editor.commit();
            return null;
        }
    }
}

